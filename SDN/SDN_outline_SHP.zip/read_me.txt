Sudan
This map shows the outline
in raw WGS84 latitude and longitude coordinates.
The files are in ESRI Shape file format.
